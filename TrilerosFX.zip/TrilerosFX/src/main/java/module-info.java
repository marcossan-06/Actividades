module org.marcos.trilerosfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens org.marcos.trilerosfx to javafx.fxml;
    exports org.marcos.trilerosfx;
}