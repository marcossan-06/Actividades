package org.marcos.trilerosfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.DialogPane;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;

public class TrileroController implements Initializable {

    public Button btn00;
    public Button btn01;
    public Button btn02;
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @Override
    @FXML
    public void initialize(URL location, ResourceBundle resources) {
        File imagenFile = new File("images/error64.png");
        Image imagenLogin = new Image(imagenFile.toURI().toString());
        ImageView img = new ImageView(imagenLogin);
        btn00.setGraphic(img);
        btn00.setDisable(true);
    }
}